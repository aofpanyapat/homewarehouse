# HomeStock — ระบบจัดการสต็อกภายในบ้าน

**ภาษาไทย | HTML + JavaScript + Cloud Firestore | ใช้งานแบบ Real-time เมื่อเชื่อม Firebase**

ระบบนี้มีหน้า Dashboard, สินค้า (SKU), Location, รับเข้า/เบิกออก, ย้าย Location,
Barcode CODE128, ประวัติ Transaction, Shopping List, และรายงานการเงิน/กราฟย้อนหลัง 6 เดือน และนำเข้ารายจ่ายจากข้อความแชตแบบหลายบรรทัด

## 1. ไฟล์ในโปรเจกต์

```
homestock_app/
├── public/
│   └── index.html      # หน้าเว็บและ logic ทั้งหมด
├── firestore.rules     # สิทธิ์การอ่านเขียนของผู้ใช้แต่ละบัญชี
├── firebase.json       # Firebase Hosting และ Firestore Rules
└── README.md
```

- **โหมด DEMO**: เปิดเว็บแล้วทดลองได้ทันที ข้อมูลอยู่ใน localStorage เฉพาะเบราว์เซอร์นั้น
- **โหมด CLOUD**: เมื่อตั้งค่า Firebase สำเร็จ ต้องล็อกอิน Google และข้อมูลเก็บใน Cloud Firestore
- **ข้อจำกัด**: ข้อมูล DEMO ไม่ย้ายเข้าคลาวด์โดยอัตโนมัติ, เวอร์ชันนี้ยังไม่มีการนำเข้า Backup JSON,
  ยังไม่มีการแชร์สต็อกระหว่าง Google account คนละบัญชี และยังไม่มีระบบเบิกแบบออฟไลน์

## 2. ตั้งค่า Firebase

1. เปิด https://console.firebase.google.com/ แล้วสร้างโปรเจกต์ใหม่
2. เข้า **Build > Firestore Database > Create database** เลือกตำแหน่งฐานข้อมูล แล้วสร้างฐานข้อมูล
3. เข้า **Build > Authentication > Sign-in method** เปิด **Google** และบันทึก
4. เข้า **Project settings > Your apps > Add app > Web** แล้วคัดลอก `firebaseConfig`
5. เปิด `public/index.html` หาส่วน `const FIREBASE_CONFIG = { ... }` แล้วนำค่าจริงแทน placeholder:

   ```js
   const FIREBASE_CONFIG = {
     apiKey: 'AIza...',
     authDomain: 'your-project.firebaseapp.com',
     projectId: 'your-project',
     appId: '1:123456:web:abcdef'
   };
   ```

   ค่าชุดนี้เป็น **Web app config (public identifiers)** ไม่ใช่ Firebase Admin private key;
   ห้ามนำ **service account JSON, private key หรือ secret อื่น** ใส่ใน index.html / GitHub.
6. เข้า **Firestore Database > Rules** แล้วใช้เนื้อหาใน `firestore.rules` กด **Publish**
   หรือ deploy Rules ผ่าน CLI ตามขั้นตอนด้านล่าง
7. หากทดสอบ localhost ให้เข้า **Authentication > Settings > Authorized domains**
   แล้วเพิ่ม `localhost` เอง (โปรเจกต์ใหม่อาจไม่เพิ่มให้อัตโนมัติ)
8. หากใช้โดเมนภายนอก เช่น GitHub Pages ให้เพิ่มโดเมนนั้นใน Authorized domains ด้วย

**ความปลอดภัย:** Rules กำหนดให้แต่ละบัญชีอ่าน/แก้ข้อมูลของตัวเองภายใต้ `users/{uid}` เท่านั้น
ไม่ควรตั้ง Rules เป็น `allow read, write: if true`.

## 3. ทดสอบบนเครื่อง

จากโฟลเดอร์โปรเจกต์:

```bash
python -m http.server 5500 --directory public
```

เปิด `http://localhost:5500` ด้วยเบราว์เซอร์ จากนั้นใช้ปุ่ม **ตั้งค่า / เชื่อมต่อ**
หรือ **ลงชื่อเข้าใช้ Google** ในหน้า Settings.

> ต้องมีอินเทอร์เน็ตสำหรับ Firebase SDK, Authentication, Real-time Sync และบริการสร้าง Barcode ผ่าน CDN.
> การสแกนกล้องใช้ BarcodeDetector API ซึ่งไม่รองรับทุกเบราว์เซอร์; สแกนเนอร์ USB แบบคีย์บอร์ดหรือกรอกรหัสเองใช้แทนได้

## 4. Deploy ขึ้น Firebase Hosting

ต้องมี Node.js ติดตั้งก่อน จากนั้นติดตั้ง Firebase CLI:

```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only firestore,hosting
```

- `firebase use --add`: เลือกโปรเจกต์ Firebase ที่สร้างไว้ และตั้ง alias `default`
- Firebase จะโฮสต์ไฟล์จากโฟลเดอร์ `public` ตาม `firebase.json`
- เมื่อ deploy สำเร็จจะได้ลิงก์ประมาณ `https://PROJECT_ID.web.app`
- ลองเข้าสู่ระบบ Google และเพิ่มสินค้า ทดสอบจากมือถืออีกเครื่องที่ล็อกอินบัญชี Google **เดียวกัน**

หากขึ้น `Permission denied` ให้ตรวจ Rules และบัญชี Google ที่ใช้งาน

## 5. เชื่อม GitHub เพื่อเก็บโค้ด

สร้าง GitHub repository เปล่า เช่น `homestock` แล้วเข้าโฟลเดอร์โปรเจกต์ ใช้คำสั่ง:

```bash
git init
git add .
git commit -m "Initial HomeStock app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/homestock.git
git push -u origin main
```

ใช้ GitHub Desktop แทนคำสั่งข้างต้นก็ได้

## 6. Deploy อัตโนมัติเมื่อ Push ไป GitHub

หลังเชื่อม repo และ deploy ครั้งแรกแล้ว รัน:

```bash
firebase init hosting:github
```

ทำตามคำถามใน CLI ให้สิทธิ์ GitHub เลือก repository และเลือกให้ deploy live เมื่อ push/merge เข้า `main`.
CLI จะช่วยสร้าง GitHub Actions workflows และจัดเก็บ Service Account Credential เป็น GitHub Secret
**อย่าคัดลอก service account key ลง repository เอง**.

เมื่อแก้โค้ด:

```bash
git add .
git commit -m "Update HomeStock"
git push
```

GitHub Actions จะช่วย deploy ไป Firebase Hosting ตาม workflow ที่สร้างไว้

เอกสารทางการ: https://firebase.google.com/docs/hosting/github-integration

## 7. วิธีใช้งานสต็อกแบบ Warehouse

1. เพิ่ม **Location** ก่อน เช่น `BDR-W01-S01` (ห้องนอน/ตู้/ชั้น)
2. เพิ่ม **สินค้า** ระบุ SKU, ชื่อสินค้า, เจ้าของ, หมวด, Location, จำนวน, ราคาต่อหน่วย
3. กด **บาร์โค้ด** ที่รายการสินค้าเพื่อพิมพ์ฉลาก CODE128 ติดกับของ
4. เมื่อหยิบไปใช้ กด **สแกนบาร์โค้ด** หรือใช้ USB scanner, จากนั้นเลือก **เบิกออก** และยืนยันจำนวน
5. ระบบจะใช้ Firestore transaction เพื่อตรวจสอบยอดล่าสุด ป้องกันยอดติดลบ และเขียนรายการเคลื่อนไหวในคำสั่งเดียว
6. ซื้อของเพิ่มให้ใช้ **รับเข้า** และเลือกว่าจะบันทึกรายจ่ายจากการซื้อนั้นหรือไม่
7. ดู Dashboard และหน้า **การเงิน / เทรนด์** รายจ่าย 6 เดือน

### ข้อจำกัดสำคัญสำหรับการใช้งานจริง

- **ยังไม่ได้ตรวจยืนยันใช้งาน Firebase กับโปรเจกต์จริงของคุณ**: ต้องกรอก Firebase Config, สร้างฐานข้อมูล, เปิด Google Sign-in, และ deploy Rules ก่อน
- Firestore transaction ต้องออนไลน์ ขณะอินเทอร์เน็ตขาดไม่อนุญาตให้เบิกแบบ offline เพื่อหลีกเลี่ยงยอดขัดแย้ง
- การออกแบบนี้เหมาะกับการใช้ส่วนตัวและปริมาณข้อมูลไม่สูง หากมีผู้ใช้งานหลายบัญชีร่วมคลังเดียวกัน ต้องเพิ่ม household membership, สิทธิ์ตามบทบาท และการตรวจยอดโดยฝั่งเซิร์ฟเวอร์
- Logs ใน Firestore เป็น immutable ต่อผู้ใช้งานผ่าน Rules ชุดนี้ แต่เจ้าของบัญชียังมีสิทธิ์แก้ข้อมูลจำนวนสินค้าในเอกสารได้ผ่าน API; ระบบองค์กรที่ต้อง Audit เข้มควรย้ายการแก้ยอดไป Cloud Functions เพื่อบังคับทุก Transaction ฝั่งเซิร์ฟเวอร์
- ควร Export JSON สำรองเป็นระยะ โดยเฉพาะข้อมูลการเงิน

## 8. ใหม่: นำเข้ารายจ่ายจากข้อความ LINE/แชต

เปิดเมนู **วางข้อความรายจ่าย** แล้ววางข้อความเช่น:

```text
เดือนตุล69
1.ทิชชู่หน้า186(1/10)
2.อาหารแมว190(1/10)
3.น้ำยาซักผ้า235(23/9)
4.ไข่160(4/10)
```

เลือก **วิเคราะห์ข้อความ** ระบบจะแยกชื่อ ราคา วันที่ และคาดเดาหมวดหมู่ โดยอ่าน `69` ในหัวข้อเดือนเป็นปี พ.ศ. 2569 (ค.ศ. 2026)
สามารถปรับแก้ข้อมูลรายบรรทัด ติ๊กเลือก ก่อนกด **บันทึกรายการที่เลือก** เพื่ออัปเดตตารางการเงินและ Dashboard

- กรณีพบชื่อ/ราคา/วันที่ไม่ชัดหรือมีหลายตัวเลข ระบบจะแจ้งเตือนและ *ไม่ติ๊กเลือกโดยอัตโนมัติ* ผู้ใช้ควรแก้ไขและติ๊กเลือกเอง
- ระบบไม่บันทึกข้อความเดิมซ้ำ หากชื่อ+ราคา+วันที่+ลำดับรายการซ้ำกับรายการที่นำเข้าก่อนหน้า (กรณีซื้อซ้ำจริงในวันเดียวกันด้วยราคาเท่ากัน อาจต้องบันทึกแยกเป็นรายการปกติ)
- การนำเข้าจะเพิ่ม **ค่าใช้จ่ายเท่านั้น** ไม่ปรับจำนวนสต็อก เพราะแชตไม่ได้ยืนยันหน่วยนับและ Location
- ใช้ **ข้อความที่คัดลอก** ไม่ใช่อัปโหลดภาพแล้ว OCR หากเป็นภาพให้พิมพ์/คัดลอกข้อความก่อน
- เมื่อยังไม่เชื่อม Firebase จะเก็บข้อมูลเฉพาะ LocalStorage ในโหมด DEMO
